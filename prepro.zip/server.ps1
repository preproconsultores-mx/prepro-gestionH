$Listener = New-Object System.Net.HttpListener
$Listener.Prefixes.Add('http://localhost:8080/')
$Listener.Start()
while ($Listener.IsListening) {
    $Context = $Listener.GetContext()
    $Request = $Context.Request
    $Response = $Context.Response
    
    $localPath = "c:\Users\dagar\Downloads\PREPRO NUEVO" + $Request.Url.LocalPath.Replace('/', '\')
    if ($localPath.EndsWith('\')) { $localPath += "index.html" }
    
    if (Test-Path $localPath) {
        $content = [System.IO.File]::ReadAllBytes($localPath)
        $Response.ContentLength64 = $content.Length
        if ($localPath.EndsWith('.html')) { $Response.ContentType = "text/html" }
        elseif ($localPath.EndsWith('.js')) { $Response.ContentType = "application/javascript" }
        elseif ($localPath.EndsWith('.css')) { $Response.ContentType = "text/css" }
        $Response.OutputStream.Write($content, 0, $content.Length)
    } else {
        $Response.StatusCode = 404
    }
    $Response.Close()
}
